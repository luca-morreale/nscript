#! /bin/sh
#
# Copyright (C) 2012 Stefano Sanfilippo. See COPYING in the main source
# package for more information
#

java -jar ./nscript.jar
